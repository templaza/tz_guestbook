jQuery(document).ready(function(){
    // ham cho the input 1
//    jQuery('#warp-input1').focus(function(){
//            var inp1 =jQuery('#warp-input1').attr('value');
//            if(inp1 =="Full name"){
//                jQuery('#warp-input1').attr('value','');
//            }
//    });
//    jQuery('#warp-input1').blur(function(){
//        var inp1 =jQuery('#warp-input1').attr('value');
//        var linp1=document.getElementById("warp-input1");
//        if(inp1==""){
//                    document.getElementById("warp-input1").value="Full name";
//                    linp1.focus();
//                    return false;
//                     }
//    });
});
//function nntinput2(){
//    var inp1 = document.getElementById("warp-input1").value;
//    var linp1=document.getElementById("warp-input1");
//        if(inp1==""){
//            document.getElementById("warp-input1").value="Full name";
//            linp1.focus();
//            return false;
//
//        }
//
//}
function nntinput3(){
    var inp3 =document.getElementById("warp-input2").value;

    if(inp3 =="Email"){
        document.getElementById("warp-input2").value ="";
    }


}
function nntinput4(){
    var inp4 = document.getElementById("warp-input2").value;
    var linp4=document.getElementById("warp-input2");
        if(inp4==""){
            document.getElementById("warp-input2").value="Email";
            linp4.focus();
            return false;
        }

}
function nntinput5(){
    var inp5 =document.getElementById("warp-input3").value;

    if(inp5 =="Title"){
        document.getElementById("warp-input3").value ="";
    }


}
function nntinput6(){
    var inp6 = document.getElementById("warp-input3").value;
    var linp6=document.getElementById("warp-input3");
        if(inp6==""){
            document.getElementById("warp-input3").value="Title";
            linp6.focus();
            return false;
        }

}
function nntinput7(){
    var inp7 =document.getElementById("text-ra").value;

    if(inp7 =="Your guestbook..."){
        document.getElementById("text-ra").value ="";
    }



}
function nntinput8(){
    var inp8 = document.getElementById("text-ra").value;
    var linp8=document.getElementById("text-ra");
        if(inp8==""){
            document.getElementById("text-ra").value="Your guestbook...";
            linp8.focus();
            return false;
        }

}
function nntinput9(){
    var inp9 =document.getElementById("warp-input4").value;
    if(inp9 =="Your website"){
        document.getElementById("warp-input4").value ="";
    }
}
function nntinput10(){
    var inp10 =document.getElementById("warp-input4").value;
    if(inp10 ==""){
        document.getElementById("warp-input4").value ="Your website";
    }



}



